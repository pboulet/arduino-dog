var structencoder__config__t =
[
    [ "DDR_ptr", "structencoder__config__t.html#ac19aefa0a3c2b6be8a8680179dc0de37", null ],
    [ "pin", "structencoder__config__t.html#ab40a673fb19c1e650e1f79de91788aa5", null ],
    [ "PORT_ptr", "structencoder__config__t.html#a0ec1802dde184eaf54eb69582c4ce128", null ],
    [ "tc_p", "structencoder__config__t.html#a647450401e726a1405d90497c9b2cd8b", null ]
];