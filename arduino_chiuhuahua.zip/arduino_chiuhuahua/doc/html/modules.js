var modules =
[
    [ "Module Wireless Interface", "group__wireless__interface.html", "group__wireless__interface" ],
    [ "USART Asynchronous Serial Module", "group__usart_async_module.html", "group__usart_async_module" ],
    [ "Module Custom Timer", "group__custom__timer.html", "group__custom__timer" ]
];