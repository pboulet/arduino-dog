var _chico_8c =
[
    [ "Mode", "_chico_8c.html#a46c8a310cf4c094f8c80e1cb8dc1f911", [
      [ "ATTACHMENT", "_chico_8c.html#a46c8a310cf4c094f8c80e1cb8dc1f911a781a603869920d53b70b44aaf638b80f", null ],
      [ "MOVEMENT", "_chico_8c.html#a46c8a310cf4c094f8c80e1cb8dc1f911a5cfb854da24ab6a30ae87ca6912e689b", null ],
      [ "SCAN_TEMPERATURES", "_chico_8c.html#a46c8a310cf4c094f8c80e1cb8dc1f911a83d91b0ce6d17bf723fc2502118a5c00", null ],
      [ "SCAN_DISTANCE", "_chico_8c.html#a46c8a310cf4c094f8c80e1cb8dc1f911a755fedc7c451f40f3618d7cb1a353ced", null ]
    ] ],
    [ "main", "_chico_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "vApplicationStackOverflowHook", "_chico_8c.html#a2e0defe473604c1bd4c5a11aed724078", null ],
    [ "attachmentState", "_chico_8c.html#ac39ca70104c70c144904380eee2e4068", null ],
    [ "centerServoPosition", "_chico_8c.html#a930926b793184ae4ee7529ae1c551188", null ],
    [ "distance", "_chico_8c.html#aa335647f17ffd88b902777114acbab4a", null ],
    [ "distanceTraveled", "_chico_8c.html#a8e06a548339e4f7efa0e7502de087682", null ],
    [ "mode", "_chico_8c.html#a2618e89b4c26dc851feae865df3a1a49", null ],
    [ "motionMode", "_chico_8c.html#aaa11cff433c79dd8912fbe2581a17167", null ],
    [ "objectDistance", "_chico_8c.html#a349303be44acbf9586448e9046f0db37", null ],
    [ "speedLeft", "_chico_8c.html#a5872565a4eb6ff5e23104cbf748f5224", null ],
    [ "speedRight", "_chico_8c.html#ae9a91d87f81f66745ac444fb2155db74", null ],
    [ "temperatures", "_chico_8c.html#ad49a07ee0c5c43ae0514a1e400e5a791", null ],
    [ "usartfd", "_chico_8c.html#ac77728f253c55ea9156a03df49e2186c", null ],
    [ "usartfd2", "_chico_8c.html#a7aa581688799ad22911143c34f34abf1", null ]
];