var _command_interface_8h =
[
    [ "INCLUDE_WEB_INTERFACE_H", "_command_interface_8h.html#a8615ed98094ea7dc4938fb1c24939608", null ],
    [ "WebCommand", "_command_interface_8h.html#a323aea4437b96bb8c99d36246b8ae792", [
      [ "FORWARD_CMD", "_command_interface_8h.html#a323aea4437b96bb8c99d36246b8ae792a3c0ceac27b72e12a2bec360b049ab9c6", null ],
      [ "BACKWARD_CMD", "_command_interface_8h.html#a323aea4437b96bb8c99d36246b8ae792ade28392bcdaa79cf503a48f18c2c6135", null ],
      [ "SPINLEFT_CMD", "_command_interface_8h.html#a323aea4437b96bb8c99d36246b8ae792a0d02a3f44a72067a51ccee1a66b85be7", null ],
      [ "SPINRIGHT_CMD", "_command_interface_8h.html#a323aea4437b96bb8c99d36246b8ae792ac7945f2a7dfa35986e071b69c197fc35", null ],
      [ "STOP_CMD", "_command_interface_8h.html#a323aea4437b96bb8c99d36246b8ae792a9f8544fefa0afdaba97209a46dd31935", null ],
      [ "ATTACHMENT_MODE_CMD", "_command_interface_8h.html#a323aea4437b96bb8c99d36246b8ae792ae92b61206f347a8c96f17366db068a12", null ],
      [ "SCAN_TEMPERATURE_CMD", "_command_interface_8h.html#a323aea4437b96bb8c99d36246b8ae792ad0bff181cc88e774a815407b511890b1", null ],
      [ "SCAN_DISTANCE_CMD", "_command_interface_8h.html#a323aea4437b96bb8c99d36246b8ae792abc876fe26b32042d33903c6cf1e76992", null ],
      [ "UNKNOWN_CMD", "_command_interface_8h.html#a323aea4437b96bb8c99d36246b8ae792a61638226c656b6dd4ad56c29d4e7c351", null ]
    ] ],
    [ "GetCommand", "_command_interface_8h.html#a328dd4fd24d7c7aab6d7e72bc7bb9ef2", null ],
    [ "InitWebInterface", "_command_interface_8h.html#a3e14121b075275ed190df8cbcb8cbf6c", null ]
];