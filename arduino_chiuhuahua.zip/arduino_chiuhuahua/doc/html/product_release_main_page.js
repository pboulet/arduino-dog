var product_release_main_page =
[
    [ "Introduction", "introduction.html", null ],
    [ "Requirements", "requirements.html", null ],
    [ "Hardwre Design", "hardware_design.html", [
      [ "Section 01", "hardware_design.html#hw_section_01", [
        [ "Subsction 01", "hardware_design.html#hw_subsection_01", null ],
        [ "hw_subsection_02", "hardware_design.html#hw_subsection_02", null ]
      ] ],
      [ "Section 02", "hardware_design.html#hw_section_02", [
        [ "Subsection 04", "hardware_design.html#hw_subsection_04", null ]
      ] ],
      [ "Section 03", "hardware_design.html#hw_section_03", [
        [ "Subsection 05", "hardware_design.html#hw_subsection_05", null ]
      ] ]
    ] ],
    [ "Software Design", "software_design.html", [
      [ "Section 01", "software_design.html#sw_section_01", [
        [ "Subsction 01", "software_design.html#sw_subsection_01", null ],
        [ "sw_subsection_02", "software_design.html#sw_subsection_02", null ]
      ] ],
      [ "Section 02", "software_design.html#sw_section_02", [
        [ "Subsection 04", "software_design.html#sw_subsection_04", null ]
      ] ],
      [ "Section 03", "software_design.html#sw_section_03", [
        [ "Subsection 05", "software_design.html#sw_subsection_05", null ]
      ] ]
    ] ]
];