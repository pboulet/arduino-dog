var structtimer__counter__parameters =
[
    [ "timer0_overflow_counter", "structtimer__counter__parameters.html#a3a5678298721913a21dd46536fa87f05", null ],
    [ "timer0_time_fraction", "structtimer__counter__parameters.html#a6735bd32d0cc20a299d6d0a5604e058b", null ],
    [ "timer0_time_in_milliseconds", "structtimer__counter__parameters.html#a036287b7f87dc5de39de35533e4880e9", null ]
];