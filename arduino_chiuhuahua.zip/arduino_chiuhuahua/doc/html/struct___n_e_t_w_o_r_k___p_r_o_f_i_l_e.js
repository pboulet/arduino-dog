var struct___n_e_t_w_o_r_k___p_r_o_f_i_l_e =
[
    [ "gateway", "struct___n_e_t_w_o_r_k___p_r_o_f_i_l_e.html#a803d5b1105de8f391d4717cf9fa1e420", null ],
    [ "local_ip_address", "struct___n_e_t_w_o_r_k___p_r_o_f_i_l_e.html#a0967ea499a8f18a404c5cddbb28ff6ab", null ],
    [ "subnet", "struct___n_e_t_w_o_r_k___p_r_o_f_i_l_e.html#ae72bea1b61c631dd95a220dcf72910cc", null ]
];