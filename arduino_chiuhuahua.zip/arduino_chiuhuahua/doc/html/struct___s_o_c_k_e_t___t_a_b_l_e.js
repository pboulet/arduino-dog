var struct___s_o_c_k_e_t___t_a_b_l_e =
[
    [ "cid", "struct___s_o_c_k_e_t___t_a_b_l_e.html#a90697eba726d8e6cb29ea51c19512d69", null ],
    [ "ip_address", "struct___s_o_c_k_e_t___t_a_b_l_e.html#a43cfeffd1fd4cfd457c5183f70d3cdaf", null ],
    [ "port", "struct___s_o_c_k_e_t___t_a_b_l_e.html#ae087d879e7211e9084cd1497ffdca89c", null ],
    [ "protocol", "struct___s_o_c_k_e_t___t_a_b_l_e.html#a3d17af0c6dbb875ff2866c1c19230085", null ],
    [ "status", "struct___s_o_c_k_e_t___t_a_b_l_e.html#aa3d1f73cc21e360d2d4e0c3b67ce3e71", null ]
];