var searchData=
[
  ['baud_5frate',['baud_rate',['../struct___g_a_i_n_s_p_a_n.html#ad855d08ab3b02ae9e82589ab5b9fd0d5',1,'_GAINSPAN']]]
];
