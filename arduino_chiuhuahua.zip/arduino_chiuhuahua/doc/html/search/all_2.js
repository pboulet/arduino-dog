var searchData=
[
  ['baud_5frate',['baud_rate',['../struct___g_a_i_n_s_p_a_n.html#ad855d08ab3b02ae9e82589ab5b9fd0d5',1,'_GAINSPAN::baud_rate()'],['../group__wireless__interface.html#gafd83f18bb43add6a2eaf3228fec2fed7',1,'BAUD_RATE():&#160;wireless_interface.h']]],
  ['baud_5frate_5f115200',['BAUD_RATE_115200',['../group__wireless__interface.html#ggafd83f18bb43add6a2eaf3228fec2fed7adb1db8d5e6fa7532419e3f2dd8a0effd',1,'wireless_interface.h']]],
  ['baud_5frate_5f9600',['BAUD_RATE_9600',['../group__wireless__interface.html#ggafd83f18bb43add6a2eaf3228fec2fed7a5c09d714c6010352674bea38d9de4b62',1,'wireless_interface.h']]],
  ['blueled',['blueLED',['../_led_8c.html#ac4ff67194a2eb29a3528cec09e79c9cf',1,'Led.c']]],
  ['boolean_5fdata',['BOOLEAN_DATA',['../group__wireless__interface.html#ga8bb14f539316556e9d58cd68b262f7b0',1,'wireless_interface.h']]],
  ['boolean_5ffalse',['BOOLEAN_FALSE',['../group__wireless__interface.html#gga8bb14f539316556e9d58cd68b262f7b0ab3f42bcdd6e94155abf3de8f5742dd9e',1,'wireless_interface.h']]],
  ['boolean_5ftrue',['BOOLEAN_TRUE',['../group__wireless__interface.html#gga8bb14f539316556e9d58cd68b262f7b0af6e8671511417cd19bc2c2ae55f0bd04',1,'wireless_interface.h']]]
];
