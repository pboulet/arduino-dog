var searchData=
[
  ['initialize_5fmodule_5ftimer0',['initialize_module_timer0',['../group__custom__timer.html#gac2aeae62e4b8528ccd841f63f83a49b4',1,'custom_timer.c']]],
  ['initialize_5fweb_5fserver',['initialize_web_server',['../group__wireless__interface.html#gac6496e86569ad26b1df8045b14eb0b71',1,'wireless_interface.c']]],
  ['initmotioncontrol',['InitMotionControl',['../_motion_control_8c.html#a24a375a5d6c7c142e0e3d03d0d26a678',1,'InitMotionControl(uint16_t *servoPosition):&#160;MotionControl.c'],['../_motion_control_8h.html#aaaaa7d2cb2b7572d73dfbec712655569',1,'InitMotionControl(uint16_t *):&#160;MotionControl.c']]],
  ['initsonarmodule',['InitSonarModule',['../_sonar_8c.html#a0b3a7c066dd37c39362afba70cc57773',1,'Sonar.c']]],
  ['inittemperaturereader',['InitTemperatureReader',['../_temperature_reader_8c.html#a93564fb1e68b721cd66d1a7e21760bdc',1,'InitTemperatureReader(void):&#160;TemperatureReader.c'],['../_temperature_reader_8h.html#a93564fb1e68b721cd66d1a7e21760bdc',1,'InitTemperatureReader(void):&#160;TemperatureReader.c']]],
  ['initwebinterface',['InitWebInterface',['../_command_interface_8c.html#a4df207f4ea3e9a766f1b0b40a362ced6',1,'InitWebInterface(void):&#160;CommandInterface.c'],['../_command_interface_8h.html#a3e14121b075275ed190df8cbcb8cbf6c',1,'InitWebInterface(void):&#160;CommandInterface.c']]],
  ['int_5fto_5fhex',['int_to_hex',['../group__wireless__interface.html#gac6ffcd32b33eedd6fc20775b3c18b044',1,'wireless_interface.c']]],
  ['invalid_5fcid',['INVALID_CID',['../group__wireless__interface.html#gac546f6531236587a348593a1ff64cfb6',1,'wireless_interface.h']]],
  ['invalid_5fport',['INVALID_PORT',['../group__wireless__interface.html#ga6f07d0094e837d61131ab0b3aa8ab1fc',1,'wireless_interface.h']]],
  ['ip_5faddress',['ip_address',['../struct___s_o_c_k_e_t___t_a_b_l_e.html#a43cfeffd1fd4cfd457c5183f70d3cdaf',1,'_SOCKET_TABLE']]],
  ['ip_5fsize',['IP_SIZE',['../group__wireless__interface.html#ga2b0b8b640f7863e341022226a4084ad9',1,'wireless_interface.c']]],
  ['isr',['ISR',['../group__custom__timer.html#gadd2d7cdddfb682dcc0391e60cf42c7d6',1,'custom_timer.c']]]
];
