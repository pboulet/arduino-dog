var searchData=
[
  ['socket_5fmode',['SOCKET_MODE',['../group__wireless__interface.html#ga2bd47c85b6411d92d82236c49fbaf567',1,'wireless_interface.h']]],
  ['socket_5fstatus',['SOCKET_STATUS',['../group__wireless__interface.html#gab7faea06bd57469129426e00fcdfe8c7',1,'wireless_interface.h']]],
  ['success_5ferror',['SUCCESS_ERROR',['../group__wireless__interface.html#ga2e53871073b531f122f463441c113633',1,'wireless_interface.h']]]
];
