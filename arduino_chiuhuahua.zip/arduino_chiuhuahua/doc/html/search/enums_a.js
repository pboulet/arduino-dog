var searchData=
[
  ['usart_5fid',['USART_ID',['../group__usart_async_module.html#gaae3c5ea77a411e5f40e4377f77067b86',1,'usart_serial.h']]],
  ['usart_5fstate',['USART_STATE',['../group__usart_async_module.html#gab7cdec2c3d93593769da070a66249537',1,'usart_serial.c']]]
];
