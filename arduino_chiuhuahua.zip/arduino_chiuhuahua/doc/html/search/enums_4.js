var searchData=
[
  ['gainspan_5factive',['GAINSPAN_ACTIVE',['../group__wireless__interface.html#ga2d6a1c69aec7812a8dc23ed99f96558e',1,'wireless_interface.h']]],
  ['gainspan_5fdevice_5foperation_5fmode',['GAINSPAN_DEVICE_OPERATION_MODE',['../group__wireless__interface.html#gab3f544ed880ca96513a544cc83b36dc1',1,'wireless_interface.h']]]
];
