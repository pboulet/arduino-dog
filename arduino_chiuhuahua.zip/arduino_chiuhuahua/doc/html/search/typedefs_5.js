var searchData=
[
  ['tcp_5fport',['TCP_PORT',['../group__wireless__interface.html#ga6be486e56223df1b41c1f3a04cb7d471',1,'wireless_interface.h']]],
  ['tcp_5fsocket',['TCP_SOCKET',['../group__wireless__interface.html#gab2d7ad3f99c2b04b0f5f5a77eefc5355',1,'wireless_interface.h']]]
];
