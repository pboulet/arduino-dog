var searchData=
[
  ['macro_5fhf',['MACRO_HF',['../template_8h.html#a7138ed1511a8cbd3c982ce20071a83b7',1,'template.h']]],
  ['macro_5fsf',['MACRO_SF',['../template_8c.html#aa292137032b645eef0bb9f5008b737b9',1,'template.c']]]
];
