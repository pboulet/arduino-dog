var searchData=
[
  ['findhuman',['FindHuman',['../_attachment_8c.html#acea9e5fc59f14d2625f3e3ae142dbc5d',1,'FindHuman(uint8_t *temperatures, AttachmentState *state):&#160;Attachment.c'],['../_attachment_8h.html#ab8b8f8f83e017b31ff900c404b12458a',1,'FindHuman(uint8_t *, AttachmentState *):&#160;Attachment.c']]],
  ['followhuman',['FollowHuman',['../_attachment_8c.html#ac1af71678f6e6ebd1d668af3e144358f',1,'FollowHuman(uint8_t *temperatures, AttachmentState *state):&#160;Attachment.c'],['../_attachment_8h.html#a7f4ad0b998fd476c8eed1763116fd393',1,'FollowHuman(uint8_t *, AttachmentState *):&#160;Attachment.c']]]
];
