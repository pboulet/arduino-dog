var searchData=
[
  ['send_5fchars',['send_chars',['../_lcd_8c.html#a4a2a6ae5887c23c3fdbc030d24a323e1',1,'Lcd.c']]],
  ['send_5fext_5fcmd',['send_ext_cmd',['../_lcd_8c.html#aebb215bf34b0018527c989a92f2e6e83',1,'Lcd.c']]],
  ['setdefaultusart',['setDefaultUSART',['../group__usart_async_module.html#gaa679900a334c7873eb71c86fe52cbf40',1,'usart_serial.c']]],
  ['setmotionmode',['setMotionMode',['../_motion_control_8c.html#acff6dfbf6fe6d08b1d2e899829819b4e',1,'setMotionMode(MotionMode _motionMode):&#160;MotionControl.c'],['../_motion_control_8h.html#af1d716703641139110d6bc4b033c78fa',1,'setMotionMode(MotionMode):&#160;MotionControl.c']]],
  ['start_5fweb_5fserver',['start_web_server',['../group__wireless__interface.html#ga199824a067b165e6f58d54f4deba7cf5',1,'wireless_interface.c']]]
];
