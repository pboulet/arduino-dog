var searchData=
[
  ['xcharsfortx',['xCharsForTx',['../struct_u_s_a_r_t___c_o_m___b_u_f.html#ae21f684842c73c2d24b3c17642a9f613',1,'USART_COM_BUF']]],
  ['xmitinterrupt_5foff',['xmitInterrupt_Off',['../group__usart_async_module.html#ga47ace99c93e8f4b284443b758cab1523',1,'usart_serial.c']]],
  ['xmitinterrupt_5fon',['xmitInterrupt_On',['../group__usart_async_module.html#gaddeaba370b80a1dd990f7f713ba7303f',1,'usart_serial.c']]],
  ['xrxedchars',['xRxedChars',['../struct_u_s_a_r_t___c_o_m___b_u_f.html#a5a624d5a247871a533bbd7686555c9fb',1,'USART_COM_BUF']]]
];
