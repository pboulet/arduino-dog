var searchData=
[
  ['baud_5frate',['BAUD_RATE',['../group__wireless__interface.html#gafd83f18bb43add6a2eaf3228fec2fed7',1,'wireless_interface.h']]],
  ['boolean_5fdata',['BOOLEAN_DATA',['../group__wireless__interface.html#ga8bb14f539316556e9d58cd68b262f7b0',1,'wireless_interface.h']]]
];
