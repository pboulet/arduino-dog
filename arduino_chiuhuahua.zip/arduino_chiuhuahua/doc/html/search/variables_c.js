var searchData=
[
  ['security_5fkey',['security_key',['../struct___g_a_i_n_s_p_a_n.html#ab64403642870a3fd324f9c3d5953839a',1,'_GAINSPAN::security_key()'],['../struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html#ab64403642870a3fd324f9c3d5953839a',1,'_WIRELESS_PROFILE::security_key()']]],
  ['serial_5fterminal_5fbaud_5frate',['serial_terminal_baud_rate',['../struct___g_a_i_n_s_p_a_n.html#aa0fcd291a2876260e1cb5167ab71218b',1,'_GAINSPAN']]],
  ['serial_5fterminal_5fusart_5fid',['serial_terminal_usart_id',['../struct___g_a_i_n_s_p_a_n.html#a53487c466835d4eaa4f73b806ed96bb2',1,'_GAINSPAN']]],
  ['server_5fcid',['server_cid',['../struct___g_a_i_n_s_p_a_n.html#a01df3cf58bcfc452deae9d48dd26c541',1,'_GAINSPAN']]],
  ['server_5fnumber_5fof_5fconnection',['server_number_of_connection',['../struct___g_a_i_n_s_p_a_n.html#ae5103bf84d893a813aca4f1e99957d48',1,'_GAINSPAN']]],
  ['server_5fport',['server_port',['../struct___w_i_f_i___s_e_r_v_e_r.html#a6fb11f0475d51296a7e29f0ebb067080',1,'_WIFI_SERVER::server_port()'],['../struct___g_a_i_n_s_p_a_n.html#a1d3c71d311fcc5c78b542f0e4fe149d3',1,'_GAINSPAN::server_port()']]],
  ['server_5fprotocol',['server_protocol',['../struct___w_i_f_i___s_e_r_v_e_r.html#a3434ea9272be5c164a3a9e8b6abd9c00',1,'_WIFI_SERVER::server_protocol()'],['../struct___g_a_i_n_s_p_a_n.html#a2c9665451fc102c0dbfb75038e62227e',1,'_GAINSPAN::server_protocol()']]],
  ['socket_5ftable',['socket_table',['../struct___g_a_i_n_s_p_a_n.html#aa107e1d600d4251a025519e62a37d893',1,'_GAINSPAN']]],
  ['socket_5fwith_5fdata',['socket_with_data',['../struct___g_a_i_n_s_p_a_n.html#a096f3cb9b10c14e2d9ed18ad0133c5dd',1,'_GAINSPAN']]],
  ['speedleft',['speedLeft',['../_chico_8c.html#a5872565a4eb6ff5e23104cbf748f5224',1,'Chico.c']]],
  ['speedright',['speedRight',['../_chico_8c.html#ae9a91d87f81f66745ac444fb2155db74',1,'Chico.c']]],
  ['ssid',['ssid',['../struct___g_a_i_n_s_p_a_n.html#a0974771b2fba5718eed6eecd656aac59',1,'_GAINSPAN::ssid()'],['../struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html#a0974771b2fba5718eed6eecd656aac59',1,'_WIRELESS_PROFILE::ssid()']]],
  ['status',['status',['../struct___s_o_c_k_e_t___t_a_b_l_e.html#aa3d1f73cc21e360d2d4e0c3b67ce3e71',1,'_SOCKET_TABLE']]],
  ['subnet',['subnet',['../struct___g_a_i_n_s_p_a_n.html#ae72bea1b61c631dd95a220dcf72910cc',1,'_GAINSPAN::subnet()'],['../struct___n_e_t_w_o_r_k___p_r_o_f_i_l_e.html#ae72bea1b61c631dd95a220dcf72910cc',1,'_NETWORK_PROFILE::subnet()']]]
];
