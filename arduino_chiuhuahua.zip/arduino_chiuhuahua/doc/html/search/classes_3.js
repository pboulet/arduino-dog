var searchData=
[
  ['tc_5fmodule_5fregisters',['tc_module_registers',['../structtc__module__registers.html',1,'']]],
  ['timer_5fcounter_5fparameters',['timer_counter_parameters',['../structtimer__counter__parameters.html',1,'']]]
];
