var searchData=
[
  ['network_5fprofile',['NETWORK_PROFILE',['../group__wireless__interface.html#ga2def26a1e0e2c837bab4804029ce3fb9',1,'wireless_interface.h']]],
  ['no_5factive_5fsocket',['NO_ACTIVE_SOCKET',['../group__wireless__interface.html#ga4295a002f81500d62db9e6aab5c525af',1,'wireless_interface.h']]],
  ['no_5fsocket_5fwtih_5fdata',['NO_SOCKET_WTIH_DATA',['../group__wireless__interface.html#ga2c931d16d52f4c5aa6930d1adc740a0a',1,'wireless_interface.h']]]
];
