var searchData=
[
  ['usart_5fcom_5fbuf',['USART_COM_BUF',['../struct_u_s_a_r_t___c_o_m___b_u_f.html',1,'']]],
  ['usart_5fregisters',['USART_REGISTERS',['../struct_u_s_a_r_t___r_e_g_i_s_t_e_r_s.html',1,'']]]
];
