var searchData=
[
  ['temperaturereader_2ec',['TemperatureReader.c',['../_temperature_reader_8c.html',1,'']]],
  ['temperaturereader_2eh',['TemperatureReader.h',['../_temperature_reader_8h.html',1,'']]]
];
