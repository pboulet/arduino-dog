var searchData=
[
  ['data_5fon_5fsocket_5fstatus',['DATA_ON_SOCKET_STATUS',['../group__wireless__interface.html#ga89e48ba1366c2ef59edbdf4e84df52bb',1,'wireless_interface.h']]],
  ['data_5ftransmission_5fcompleted',['data_transmission_completed',['../struct___g_a_i_n_s_p_a_n.html#ae7f400899955f893db236e8382f0b7be',1,'_GAINSPAN']]],
  ['defaultusart',['defaultUSART',['../group__usart_async_module.html#ga88cfc7c9ded2bea56fff795fe46b68c0',1,'usart_serial.c']]],
  ['delay_5fmilliseconds',['delay_milliseconds',['../group__custom__timer.html#gaa10b6cff287b214da3fe126055ba32a3',1,'custom_timer.c']]],
  ['device_5fconnection_5fstatus',['device_connection_status',['../struct___g_a_i_n_s_p_a_n.html#a3eb8965ef026c39cc8e5eb37073d1dd2',1,'_GAINSPAN::device_connection_status()'],['../group__wireless__interface.html#gab5114867e594e54bbfdb6552c8650fff',1,'DEVICE_CONNECTION_STATUS():&#160;wireless_interface.h']]],
  ['device_5foperation_5fmode',['device_operation_mode',['../struct___g_a_i_n_s_p_a_n.html#ac58cfc15cdeb3c36748f2b91a8bbf38a',1,'_GAINSPAN']]],
  ['distance',['distance',['../_chico_8c.html#aa335647f17ffd88b902777114acbab4a',1,'Chico.c']]],
  ['distancetraveled',['distanceTraveled',['../_chico_8c.html#a8e06a548339e4f7efa0e7502de087682',1,'Chico.c']]]
];
