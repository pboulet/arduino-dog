var searchData=
[
  ['local_5fip_5faddress',['local_ip_address',['../struct___g_a_i_n_s_p_a_n.html#a0967ea499a8f18a404c5cddbb28ff6ab',1,'_GAINSPAN::local_ip_address()'],['../struct___n_e_t_w_o_r_k___p_r_o_f_i_l_e.html#a0967ea499a8f18a404c5cddbb28ff6ab',1,'_NETWORK_PROFILE::local_ip_address()']]]
];
