var searchData=
[
  ['gainspan_5factive_5ffalse',['GAINSPAN_ACTIVE_FALSE',['../group__wireless__interface.html#gga2d6a1c69aec7812a8dc23ed99f96558eac5e8200121882454bb5a1eef24d3dec1',1,'wireless_interface.h']]],
  ['gainspan_5factive_5ftrue',['GAINSPAN_ACTIVE_TRUE',['../group__wireless__interface.html#gga2d6a1c69aec7812a8dc23ed99f96558ea8b9a4426f4574b1bb24b0bc55abfc0d9',1,'wireless_interface.h']]],
  ['gainspan_5factive_5ftrue_5fwith_5ferrors',['GAINSPAN_ACTIVE_TRUE_WITH_ERRORS',['../group__wireless__interface.html#gga2d6a1c69aec7812a8dc23ed99f96558ea41c2f910c639fb4214bfbe08c342d6e1',1,'wireless_interface.h']]],
  ['gainspan_5fdevice_5fmode_5fcommand',['GAINSPAN_DEVICE_MODE_COMMAND',['../group__wireless__interface.html#ggab3f544ed880ca96513a544cc83b36dc1af3dbf03c29f3997d26e2498cd6d27f59',1,'wireless_interface.h']]],
  ['gainspan_5fdevice_5fmode_5fdata',['GAINSPAN_DEVICE_MODE_DATA',['../group__wireless__interface.html#ggab3f544ed880ca96513a544cc83b36dc1aa12a645c46b95f7d32279ed56fa94d0f',1,'wireless_interface.h']]],
  ['gainspan_5fdevice_5fmode_5fdata_5frx',['GAINSPAN_DEVICE_MODE_DATA_RX',['../group__wireless__interface.html#ggab3f544ed880ca96513a544cc83b36dc1a7b28d347d7d9a4d7dacac916c948e48b',1,'wireless_interface.h']]]
];
