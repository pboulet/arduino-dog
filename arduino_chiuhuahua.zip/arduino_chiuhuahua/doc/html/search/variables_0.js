var searchData=
[
  ['active_5fclient_5fcid',['active_client_cid',['../struct___g_a_i_n_s_p_a_n.html#af1a3dbed6e7b958d3aac14f55d7fd0e4',1,'_GAINSPAN']]],
  ['active_5fsocket',['active_socket',['../struct___g_a_i_n_s_p_a_n.html#a343615f6a4f9b4eb515f54dbfc47509d',1,'_GAINSPAN']]],
  ['attachmentstate',['attachmentState',['../_chico_8c.html#ac39ca70104c70c144904380eee2e4068',1,'Chico.c']]],
  ['authentication_5fmode',['authentication_mode',['../struct___g_a_i_n_s_p_a_n.html#aeca435227975bb33677e5d117f229833',1,'_GAINSPAN::authentication_mode()'],['../struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html#aeca435227975bb33677e5d117f229833',1,'_WIRELESS_PROFILE::authentication_mode()']]]
];
