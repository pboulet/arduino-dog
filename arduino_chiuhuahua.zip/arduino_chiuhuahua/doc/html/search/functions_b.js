var searchData=
[
  ['readspeed',['readSpeed',['../_motion_control_8c.html#a9ae9d55ac7312e8bc02ecac891d91951',1,'readSpeed(double *speedLeft, double *speedRight, double *distance):&#160;MotionControl.c'],['../_motion_control_8h.html#ad7124b9c746b520b72c520e14a0d4a62',1,'readSpeed(double *, double *, double *):&#160;MotionControl.c']]],
  ['redled',['redLED',['../_led_8c.html#a4e7a551555e2f0e5f13551185fe65853',1,'Led.c']]]
];
