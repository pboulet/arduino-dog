var searchData=
[
  ['protocol_5ftcp',['PROTOCOL_TCP',['../group__wireless__interface.html#gga2966051bfea778d846d94013f7cb888dae991c7cad918269624b3c28147e18a93',1,'wireless_interface.h']]],
  ['protocol_5fudp',['PROTOCOL_UDP',['../group__wireless__interface.html#gga2966051bfea778d846d94013f7cb888da3c79df624160aa6dbeeb4e2c13ca3dc7',1,'wireless_interface.h']]],
  ['protocol_5fudp_5fclient',['PROTOCOL_UDP_CLIENT',['../group__wireless__interface.html#gga2966051bfea778d846d94013f7cb888daae722834ed0570e683dd89a383c9cc6a',1,'wireless_interface.h']]]
];
