var searchData=
[
  ['xcharsfortx',['xCharsForTx',['../struct_u_s_a_r_t___c_o_m___b_u_f.html#ae21f684842c73c2d24b3c17642a9f613',1,'USART_COM_BUF']]],
  ['xrxedchars',['xRxedChars',['../struct_u_s_a_r_t___c_o_m___b_u_f.html#a5a624d5a247871a533bbd7686555c9fb',1,'USART_COM_BUF']]]
];
