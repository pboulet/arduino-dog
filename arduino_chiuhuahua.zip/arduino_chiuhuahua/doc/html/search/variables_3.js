var searchData=
[
  ['data_5ftransmission_5fcompleted',['data_transmission_completed',['../struct___g_a_i_n_s_p_a_n.html#ae7f400899955f893db236e8382f0b7be',1,'_GAINSPAN']]],
  ['defaultusart',['defaultUSART',['../group__usart_async_module.html#ga88cfc7c9ded2bea56fff795fe46b68c0',1,'usart_serial.c']]],
  ['device_5fconnection_5fstatus',['device_connection_status',['../struct___g_a_i_n_s_p_a_n.html#a3eb8965ef026c39cc8e5eb37073d1dd2',1,'_GAINSPAN']]],
  ['device_5foperation_5fmode',['device_operation_mode',['../struct___g_a_i_n_s_p_a_n.html#ac58cfc15cdeb3c36748f2b91a8bbf38a',1,'_GAINSPAN']]],
  ['distance',['distance',['../_chico_8c.html#aa335647f17ffd88b902777114acbab4a',1,'Chico.c']]],
  ['distancetraveled',['distanceTraveled',['../_chico_8c.html#a8e06a548339e4f7efa0e7502de087682',1,'Chico.c']]]
];
