var searchData=
[
  ['socket_5fdata_5favailable_5fno',['SOCKET_DATA_AVAILABLE_NO',['../group__wireless__interface.html#gga89e48ba1366c2ef59edbdf4e84df52bba439dd79d2d29db795e8af9121d1d26dd',1,'wireless_interface.h']]],
  ['socket_5fdata_5favailable_5fyes',['SOCKET_DATA_AVAILABLE_YES',['../group__wireless__interface.html#gga89e48ba1366c2ef59edbdf4e84df52bba2a7c83420792cb720d29006242753c7c',1,'wireless_interface.h']]],
  ['socket_5fmode_5fenable',['SOCKET_MODE_ENABLE',['../group__wireless__interface.html#gga2bd47c85b6411d92d82236c49fbaf567a27f9a7786e887936fa93893312821fe0',1,'wireless_interface.h']]],
  ['socket_5fmode_5fprocess',['SOCKET_MODE_PROCESS',['../group__wireless__interface.html#gga2bd47c85b6411d92d82236c49fbaf567a85c612afc4a587d9ccb67ca9ba78d20f',1,'wireless_interface.h']]],
  ['socket_5fstatus_5fclose_5fwait',['SOCKET_STATUS_CLOSE_WAIT',['../group__wireless__interface.html#ggab7faea06bd57469129426e00fcdfe8c7a4c100900fae92e68bbbcce4bee19997f',1,'wireless_interface.h']]],
  ['socket_5fstatus_5fclosed',['SOCKET_STATUS_CLOSED',['../group__wireless__interface.html#ggab7faea06bd57469129426e00fcdfe8c7a3da8e4770a81565bb707ffcf0c7010a9',1,'wireless_interface.h']]],
  ['socket_5fstatus_5festablished',['SOCKET_STATUS_ESTABLISHED',['../group__wireless__interface.html#ggab7faea06bd57469129426e00fcdfe8c7a09a0124f619b539930828c3a0f14c1fc',1,'wireless_interface.h']]],
  ['socket_5fstatus_5finit',['SOCKET_STATUS_INIT',['../group__wireless__interface.html#ggab7faea06bd57469129426e00fcdfe8c7aa33144a60f78ef0aecce8542bdb67c1d',1,'wireless_interface.h']]],
  ['socket_5fstatus_5finvalid',['SOCKET_STATUS_INVALID',['../group__wireless__interface.html#ggab7faea06bd57469129426e00fcdfe8c7ad966b85f9f58bbdc162e40b1f7bf351e',1,'wireless_interface.h']]],
  ['socket_5fstatus_5flisten',['SOCKET_STATUS_LISTEN',['../group__wireless__interface.html#ggab7faea06bd57469129426e00fcdfe8c7a91888376ff31f50986be7e2eaa17e732',1,'wireless_interface.h']]],
  ['success',['SUCCESS',['../group__wireless__interface.html#gga2e53871073b531f122f463441c113633ac7f69f7c9e5aea9b8f54cf02870e2bf8',1,'wireless_interface.h']]]
];
