var searchData=
[
  ['baud_5frate_5f115200',['BAUD_RATE_115200',['../group__wireless__interface.html#ggafd83f18bb43add6a2eaf3228fec2fed7adb1db8d5e6fa7532419e3f2dd8a0effd',1,'wireless_interface.h']]],
  ['baud_5frate_5f9600',['BAUD_RATE_9600',['../group__wireless__interface.html#ggafd83f18bb43add6a2eaf3228fec2fed7a5c09d714c6010352674bea38d9de4b62',1,'wireless_interface.h']]],
  ['boolean_5ffalse',['BOOLEAN_FALSE',['../group__wireless__interface.html#gga8bb14f539316556e9d58cd68b262f7b0ab3f42bcdd6e94155abf3de8f5742dd9e',1,'wireless_interface.h']]],
  ['boolean_5ftrue',['BOOLEAN_TRUE',['../group__wireless__interface.html#gga8bb14f539316556e9d58cd68b262f7b0af6e8671511417cd19bc2c2ae55f0bd04',1,'wireless_interface.h']]]
];
