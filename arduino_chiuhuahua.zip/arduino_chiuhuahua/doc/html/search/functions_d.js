var searchData=
[
  ['temperaturesweep',['temperatureSweep',['../_motion_control_8c.html#a7d2e667a9c94c6aa401413a1d5ab6396',1,'temperatureSweep(MotionMode mode, uint16_t *servoPosition):&#160;MotionControl.c'],['../_motion_control_8h.html#ab500b28fe13da2f86b52ebec346d8fab',1,'temperatureSweep(MotionMode, uint16_t *):&#160;MotionControl.c']]],
  ['time_5fin_5fmicroseconds',['time_in_microseconds',['../group__custom__timer.html#gada8ec2a9d8790c2818e0094855ecdb7e',1,'custom_timer.c']]],
  ['time_5fin_5fmilliseconds',['time_in_milliseconds',['../group__custom__timer.html#gae3c70f50721e84e6761da58ff419f865',1,'custom_timer.c']]]
];
