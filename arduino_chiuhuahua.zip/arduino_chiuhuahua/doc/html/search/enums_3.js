var searchData=
[
  ['data_5fon_5fsocket_5fstatus',['DATA_ON_SOCKET_STATUS',['../group__wireless__interface.html#ga89e48ba1366c2ef59edbdf4e84df52bb',1,'wireless_interface.h']]],
  ['device_5fconnection_5fstatus',['DEVICE_CONNECTION_STATUS',['../group__wireless__interface.html#gab5114867e594e54bbfdb6552c8650fff',1,'wireless_interface.h']]]
];
