var struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e =
[
    [ "authentication_mode", "struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html#aeca435227975bb33677e5d117f229833", null ],
    [ "security_key", "struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html#ab64403642870a3fd324f9c3d5953839a", null ],
    [ "ssid", "struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html#a0974771b2fba5718eed6eecd656aac59", null ],
    [ "transmission_rate", "struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html#abc31b3221cb4cd4bac2011146c01155b", null ],
    [ "wireless_channel", "struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html#aae9ab5f7e222ed6c0b6c0863e062c80d", null ],
    [ "wireless_mode", "struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html#a10c5fd316b87e0948f23db8cd5d3c186", null ],
    [ "wireless_security_configuration", "struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html#ad018e91f1bc78adc81fbb06387d408e1", null ]
];