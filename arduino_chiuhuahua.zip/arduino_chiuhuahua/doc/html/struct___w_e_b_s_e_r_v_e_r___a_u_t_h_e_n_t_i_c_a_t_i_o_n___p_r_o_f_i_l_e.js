var struct___w_e_b_s_e_r_v_e_r___a_u_t_h_e_n_t_i_c_a_t_i_o_n___p_r_o_f_i_l_e =
[
    [ "web_server_administrator_id", "struct___w_e_b_s_e_r_v_e_r___a_u_t_h_e_n_t_i_c_a_t_i_o_n___p_r_o_f_i_l_e.html#ab4eff72463ceb5705e1d25785f9a560f", null ],
    [ "web_server_administrator_password", "struct___w_e_b_s_e_r_v_e_r___a_u_t_h_e_n_t_i_c_a_t_i_o_n___p_r_o_f_i_l_e.html#ab4052cb1635dfab273e72851f2d21b00", null ]
];