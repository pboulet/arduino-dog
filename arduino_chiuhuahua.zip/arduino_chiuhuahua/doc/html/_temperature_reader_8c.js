var _temperature_reader_8c =
[
    [ "getTemperatureFromSensor", "_temperature_reader_8c.html#a8e5a5eed223afd337f93ba364dc2d22f", null ],
    [ "InitTemperatureReader", "_temperature_reader_8c.html#a93564fb1e68b721cd66d1a7e21760bdc", null ]
];