var struct___h_t_m_l___w_e_b___p_a_g_e =
[
    [ "element_count", "struct___h_t_m_l___w_e_b___p_a_g_e.html#ab3daa6b1888172c2b538b3029cb51f8b", null ],
    [ "element_type", "struct___h_t_m_l___w_e_b___p_a_g_e.html#a95169877b05df1f4298171b3e19ab812", null ],
    [ "menu_title", "struct___h_t_m_l___w_e_b___p_a_g_e.html#adb16b1f68c491326067f4852e810beec", null ],
    [ "page_title", "struct___h_t_m_l___w_e_b___p_a_g_e.html#a390bc1c559142d5288b6e2798881c057", null ],
    [ "web_page_elements", "struct___h_t_m_l___w_e_b___p_a_g_e.html#abcca79a3c457dfe32a505f56e8124c94", null ]
];