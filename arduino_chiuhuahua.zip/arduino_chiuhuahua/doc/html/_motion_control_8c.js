var _motion_control_8c =
[
    [ "InitMotionControl", "_motion_control_8c.html#a24a375a5d6c7c142e0e3d03d0d26a678", null ],
    [ "readSpeed", "_motion_control_8c.html#a9ae9d55ac7312e8bc02ecac891d91951", null ],
    [ "setMotionMode", "_motion_control_8c.html#acff6dfbf6fe6d08b1d2e899829819b4e", null ],
    [ "temperatureSweep", "_motion_control_8c.html#a7d2e667a9c94c6aa401413a1d5ab6396", null ],
    [ "updateRobotMotion", "_motion_control_8c.html#a5eb131787ba337dcd27dbe14d2d13f39", null ],
    [ "clockwise", "_motion_control_8c.html#a3edf479ca9ede2b8669a2a251834a229", null ],
    [ "leftRotationTicks", "_motion_control_8c.html#acdd41d557392445016d13a8d1b4abd29", null ],
    [ "leftWheelPulseWidth", "_motion_control_8c.html#ae54e4ed10e6828e6c3a30061ef5253b0", null ],
    [ "motionMode", "_motion_control_8c.html#aaa11cff433c79dd8912fbe2581a17167", null ],
    [ "moving", "_motion_control_8c.html#ad892143587536d5edaac114b6d9b38f6", null ],
    [ "numRisingEdgesForAvg", "_motion_control_8c.html#ab335ff9cc680d4f8a136909013ef589a", null ],
    [ "observationLeftCtr", "_motion_control_8c.html#a229dfecf60d0f79bf71ead5b474de3ea", null ],
    [ "observationRightCtr", "_motion_control_8c.html#ac3ba6cebd32fb5ae2da1caddb5843410", null ],
    [ "rightRotationTicks", "_motion_control_8c.html#a05aa4644f07e00fba1cde27c789b7bd4", null ],
    [ "rightWheelPulseWidth", "_motion_control_8c.html#a8e6a379f1fb51eedc4df32a7ad5c3118", null ]
];