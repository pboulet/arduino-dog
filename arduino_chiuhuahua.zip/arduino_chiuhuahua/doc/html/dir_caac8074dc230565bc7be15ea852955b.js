var dir_caac8074dc230565bc7be15ea852955b =
[
    [ "TemperatureReader.c", "_temperature_reader_8c.html", "_temperature_reader_8c" ],
    [ "TemperatureReader.h", "_temperature_reader_8h.html", "_temperature_reader_8h" ]
];