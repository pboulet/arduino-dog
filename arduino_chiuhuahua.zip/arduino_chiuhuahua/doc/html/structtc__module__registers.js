var structtc__module__registers =
[
    [ "ICR_ptr", "structtc__module__registers.html#a3c72e73632131a1f61c9da3f17dbb823", null ],
    [ "prescale", "structtc__module__registers.html#ad4f9eb028b4dee0645920af8f0d86df9", null ],
    [ "TCCR_A_ptr", "structtc__module__registers.html#a58b13735f3b62e0130a57dfe35fbf54d", null ],
    [ "TCCR_B_ptr", "structtc__module__registers.html#a2312ee654c987cef8db58551bfa8b352", null ],
    [ "TCNT_ptr", "structtc__module__registers.html#afbf5f6709d85a6a246efcdcfabc602ce", null ],
    [ "TIFR_ptr", "structtc__module__registers.html#a53f93e613ee6820fa9ffdae94421c178", null ],
    [ "TIMSK_ptr", "structtc__module__registers.html#a1ba7c320d8e895abe04ff75fdd6d7103", null ],
    [ "TOP_value_p", "structtc__module__registers.html#a0a9ca9d3b4d0028967930c03ce30fd03", null ],
    [ "wgm_mode", "structtc__module__registers.html#ac36942801473eb5b93134ca940c4e190", null ]
];