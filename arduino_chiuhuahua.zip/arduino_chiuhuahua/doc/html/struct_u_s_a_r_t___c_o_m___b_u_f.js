var struct_u_s_a_r_t___c_o_m___b_u_f =
[
    [ "workBuffer", "struct_u_s_a_r_t___c_o_m___b_u_f.html#a3e5364327574de8fbd221bb5e037275a", null ],
    [ "workBufferInUse", "struct_u_s_a_r_t___c_o_m___b_u_f.html#aa6ed1e9b2683679ff84b1a30b2f80422", null ],
    [ "workBufferSize", "struct_u_s_a_r_t___c_o_m___b_u_f.html#a0c7c3605804de7486d0886f759a0e15e", null ],
    [ "xCharsForTx", "struct_u_s_a_r_t___c_o_m___b_u_f.html#ae21f684842c73c2d24b3c17642a9f613", null ],
    [ "xRxedChars", "struct_u_s_a_r_t___c_o_m___b_u_f.html#a5a624d5a247871a533bbd7686555c9fb", null ]
];