var annotated_dup =
[
    [ "_GAINSPAN", "struct___g_a_i_n_s_p_a_n.html", "struct___g_a_i_n_s_p_a_n" ],
    [ "_HTML_ELEMENT_CHOICE", "struct___h_t_m_l___e_l_e_m_e_n_t___c_h_o_i_c_e.html", "struct___h_t_m_l___e_l_e_m_e_n_t___c_h_o_i_c_e" ],
    [ "_HTML_WEB_PAGE", "struct___h_t_m_l___w_e_b___p_a_g_e.html", "struct___h_t_m_l___w_e_b___p_a_g_e" ],
    [ "_NETWORK_PROFILE", "struct___n_e_t_w_o_r_k___p_r_o_f_i_l_e.html", "struct___n_e_t_w_o_r_k___p_r_o_f_i_l_e" ],
    [ "_SOCKET_TABLE", "struct___s_o_c_k_e_t___t_a_b_l_e.html", "struct___s_o_c_k_e_t___t_a_b_l_e" ],
    [ "_WEBSERVER_AUTHENTICATION_PROFILE", "struct___w_e_b_s_e_r_v_e_r___a_u_t_h_e_n_t_i_c_a_t_i_o_n___p_r_o_f_i_l_e.html", "struct___w_e_b_s_e_r_v_e_r___a_u_t_h_e_n_t_i_c_a_t_i_o_n___p_r_o_f_i_l_e" ],
    [ "_WIFI_CLIENT", "struct___w_i_f_i___c_l_i_e_n_t.html", "struct___w_i_f_i___c_l_i_e_n_t" ],
    [ "_WIFI_SERVER", "struct___w_i_f_i___s_e_r_v_e_r.html", "struct___w_i_f_i___s_e_r_v_e_r" ],
    [ "_WIRELESS_PROFILE", "struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e.html", "struct___w_i_r_e_l_e_s_s___p_r_o_f_i_l_e" ],
    [ "encoder_config_t", "structencoder__config__t.html", "structencoder__config__t" ],
    [ "motor_registers_s", "structmotor__registers__s.html", "structmotor__registers__s" ],
    [ "tc_module_registers", "structtc__module__registers.html", "structtc__module__registers" ],
    [ "timer_counter_parameters", "structtimer__counter__parameters.html", "structtimer__counter__parameters" ],
    [ "USART_COM_BUF", "struct_u_s_a_r_t___c_o_m___b_u_f.html", "struct_u_s_a_r_t___c_o_m___b_u_f" ],
    [ "USART_REGISTERS", "struct_u_s_a_r_t___r_e_g_i_s_t_e_r_s.html", "struct_u_s_a_r_t___r_e_g_i_s_t_e_r_s" ]
];