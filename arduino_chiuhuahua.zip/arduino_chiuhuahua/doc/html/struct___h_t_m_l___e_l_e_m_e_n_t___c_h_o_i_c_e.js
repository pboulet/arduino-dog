var struct___h_t_m_l___e_l_e_m_e_n_t___c_h_o_i_c_e =
[
    [ "element_identifier", "struct___h_t_m_l___e_l_e_m_e_n_t___c_h_o_i_c_e.html#ad4cd2cbc892cf8e1c15083ee9f1b3f49", null ],
    [ "element_label", "struct___h_t_m_l___e_l_e_m_e_n_t___c_h_o_i_c_e.html#a98a17ef448502d816c911439a3c70445", null ]
];