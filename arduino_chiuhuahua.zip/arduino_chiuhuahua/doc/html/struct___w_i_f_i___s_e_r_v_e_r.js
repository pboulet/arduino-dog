var struct___w_i_f_i___s_e_r_v_e_r =
[
    [ "server_port", "struct___w_i_f_i___s_e_r_v_e_r.html#a6fb11f0475d51296a7e29f0ebb067080", null ],
    [ "server_protocol", "struct___w_i_f_i___s_e_r_v_e_r.html#a3434ea9272be5c164a3a9e8b6abd9c00", null ]
];