var _motion_control_8h =
[
    [ "MotionMode", "_motion_control_8h.html#a1af74a820fe5dfe2ba8109cec07fbb43", [
      [ "FORWARD", "_motion_control_8h.html#a1af74a820fe5dfe2ba8109cec07fbb43aa26736999186daf8146f809e863712a1", null ],
      [ "BACKWARD", "_motion_control_8h.html#a1af74a820fe5dfe2ba8109cec07fbb43afed2fca77e454294d6b8bda1bf2c9fd6", null ],
      [ "SPINLEFT", "_motion_control_8h.html#a1af74a820fe5dfe2ba8109cec07fbb43a0091a7baaf5bfd4c94b970e538473701", null ],
      [ "SPINRIGHT", "_motion_control_8h.html#a1af74a820fe5dfe2ba8109cec07fbb43a97b3f20bbf06e46e35d021d74b3d18cd", null ],
      [ "STOP", "_motion_control_8h.html#a1af74a820fe5dfe2ba8109cec07fbb43a679ee5320d66c8322e310daeb2ee99b8", null ],
      [ "UNKNOWN", "_motion_control_8h.html#a1af74a820fe5dfe2ba8109cec07fbb43a6ce26a62afab55d7606ad4e92428b30c", null ]
    ] ],
    [ "InitMotionControl", "_motion_control_8h.html#aaaaa7d2cb2b7572d73dfbec712655569", null ],
    [ "readSpeed", "_motion_control_8h.html#ad7124b9c746b520b72c520e14a0d4a62", null ],
    [ "setMotionMode", "_motion_control_8h.html#af1d716703641139110d6bc4b033c78fa", null ],
    [ "temperatureSweep", "_motion_control_8h.html#ab500b28fe13da2f86b52ebec346d8fab", null ],
    [ "updateRobotMotion", "_motion_control_8h.html#a115a49e5ca74112b0c286b274b7320a2", null ]
];