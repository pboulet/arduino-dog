var files =
[
    [ "attachment", "dir_e8e011b1f5da56d4d2a486e3fad63bfe.html", "dir_e8e011b1f5da56d4d2a486e3fad63bfe" ],
    [ "commandInterface", "dir_cd5bad576acf20b5ab533f6ccb214d04.html", "dir_cd5bad576acf20b5ab533f6ccb214d04" ],
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "lcd", "dir_7539740a674fe554df3e16c8629ce56f.html", "dir_7539740a674fe554df3e16c8629ce56f" ],
    [ "led", "dir_8d7fb7195de960b61f8df2d10bde2a96.html", "dir_8d7fb7195de960b61f8df2d10bde2a96" ],
    [ "motion", "dir_87a0df428f6a2da77e8f5b68af94d31f.html", "dir_87a0df428f6a2da77e8f5b68af94d31f" ],
    [ "sonar", "dir_dfc317270c89deb8038687819d9c4f9f.html", "dir_dfc317270c89deb8038687819d9c4f9f" ],
    [ "temperatureReader", "dir_caac8074dc230565bc7be15ea852955b.html", "dir_caac8074dc230565bc7be15ea852955b" ],
    [ "Chico.c", "_chico_8c.html", "_chico_8c" ]
];