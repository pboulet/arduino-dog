var _temperature_reader_8h =
[
    [ "BASE_REGISTER", "_temperature_reader_8h.html#acafa99ecabfc358ed468452d3e26f2b4", null ],
    [ "I2C_READ_ADDR", "_temperature_reader_8h.html#a11a0148c64950f3315f38d957cd43d37", null ],
    [ "I2C_WRITE_ADDR", "_temperature_reader_8h.html#a7978167075eb8954c1090fc7ce9647c6", null ],
    [ "getTemperatureFromSensor", "_temperature_reader_8h.html#a2fb62e5847557cafcaf436ad77ba3dbc", null ],
    [ "InitTemperatureReader", "_temperature_reader_8h.html#a93564fb1e68b721cd66d1a7e21760bdc", null ]
];