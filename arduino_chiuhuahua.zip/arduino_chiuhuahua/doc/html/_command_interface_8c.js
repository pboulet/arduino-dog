var _command_interface_8c =
[
    [ "GetCommand", "_command_interface_8c.html#a801d5e9f1352972fa3c6526e38727ca8", null ],
    [ "InitWebInterface", "_command_interface_8c.html#a4df207f4ea3e9a766f1b0b40a362ced6", null ],
    [ "commands", "_command_interface_8c.html#af6d420e90317e3bb46bc2b5beb258d2b", null ],
    [ "commandsTxt", "_command_interface_8c.html#a9c391dd90703c8cf2ff417b0d62e5c05", null ]
];