var struct___w_i_f_i___c_l_i_e_n_t =
[
    [ "client_socket", "struct___w_i_f_i___c_l_i_e_n_t.html#ae3e20d0266bcdfb1ec188befb5a33fda", null ]
];