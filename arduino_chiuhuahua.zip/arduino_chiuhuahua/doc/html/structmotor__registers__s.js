var structmotor__registers__s =
[
    [ "channel", "structmotor__registers__s.html#a715f5cb061d11eb75981741eda4dafcd", null ],
    [ "DDR_ptr", "structmotor__registers__s.html#ac19aefa0a3c2b6be8a8680179dc0de37", null ],
    [ "OCR_ptr", "structmotor__registers__s.html#a072ed0d39dc707bfcdcd515f0d67e3d1", null ],
    [ "pin", "structmotor__registers__s.html#ab40a673fb19c1e650e1f79de91788aa5", null ],
    [ "PORT_ptr", "structmotor__registers__s.html#a0ec1802dde184eaf54eb69582c4ce128", null ],
    [ "tc_p", "structmotor__registers__s.html#a647450401e726a1405d90497c9b2cd8b", null ]
];