var struct_u_s_a_r_t___r_e_g_i_s_t_e_r_s =
[
    [ "ubbrPtr", "struct_u_s_a_r_t___r_e_g_i_s_t_e_r_s.html#a424b04e01c751eb123010d53efdceb69", null ],
    [ "ucsrAPtr", "struct_u_s_a_r_t___r_e_g_i_s_t_e_r_s.html#a91317f154b3126632a2a491aeff89539", null ],
    [ "ucsrBPtr", "struct_u_s_a_r_t___r_e_g_i_s_t_e_r_s.html#a248eedccefc78b9ed1391f723b363e62", null ],
    [ "ucsrCPtr", "struct_u_s_a_r_t___r_e_g_i_s_t_e_r_s.html#a4e331f842d0fc12e9a910975ca49106b", null ],
    [ "udrPtr", "struct_u_s_a_r_t___r_e_g_i_s_t_e_r_s.html#aabd7903c98babfe883a412b3ee00e673", null ]
];